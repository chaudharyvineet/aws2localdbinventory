import os
import requests

def lambda_handler(event, context):
    

    filename = os.environ.get('FILENAME', 'default.txt')
    file_path = f"/mnt/efs/{filename}"
    
    with open(file_path, "w") as file:
        file.write("Hello, EFS!")

    # response = requests.get("https://api.ipify.org?format=json")
    # public_ip = response.json().get("ip")
    
    return {
        'statusCode': 200,
        'body': f'File written to {file_path}'
    }


